let detectGovernanceViolations =
  typeof globalThis.detectGovernanceViolations === "function"
    ? globalThis.detectGovernanceViolations
    : null;

function initialValidationState() {
  return {
    forbiddenHits: [],
    wordCountOk: true,
    artifactsOk: true,
    impliedReliabilityOk: true,
    isCompliant: false,
  };
}

async function validatorPass(text, { input, rules, governanceStrictness }) {
  if (typeof detectGovernanceViolations !== "function") {
    detectGovernanceViolations =
      require("./runGovernedWorkflow").detectGovernanceViolations;
  }
  const evaluation = detectGovernanceViolations(text);
  const base = initialValidationState();
  const merged = { ...base, ...evaluation };
  merged.isCompliant =
    merged.artifactsOk &&
    merged.impliedReliabilityOk &&
    (merged.forbiddenHits || []).length === 0 &&
    (merged.hardViolationCount || 0) === 0;
  return merged;
}

module.exports = {
  validatorPass,
};
