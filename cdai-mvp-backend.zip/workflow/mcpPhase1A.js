// V1-PHASE1A: structural enums
const MCP_EVENTS = {
  CYCLE_START: "mcp:cycle_start",
  ENTER_ANALYTICAL: "mcp:enter_analytical",
  ENTER_MODERATOR_1: "mcp:enter_moderator_1",
  ENTER_CREATIVE: "mcp:enter_creative",
  ENTER_MODERATOR_2: "mcp:enter_moderator_2",
  ENTER_VALIDATOR: "mcp:enter_validator",
  CYCLE_COMPLETE: "mcp:cycle_complete",
  CLARIFICATION_REQUIRED: "mcp:clarification_required",
  CLARIFICATION_RECEIVED: "mcp:clarification_received",
};

// V1-PHASE1A: structural enums
const REQUEST_TYPES = {
  CONVERSATIONAL: "conversational",
  GOVERNED: "governed_request",
  UNGOVERNED: "ungoverned_request",
  CLARIFICATION_RESPONSE: "clarification_response",
};

// V1-PHASE5: extended governance decisions
const GOVERNANCE_DECISIONS = {
  ALLOW: "allow",
  REQUIRE_RULES: "require_rules",
  BLOCK: "block",
  ASK_CLARIFICATION: "ask_clarification",
};

// V1.2-PHASE1: allowed data scope modes
const DATA_SCOPE_MODES = {
  WORK: "work",
  WEB: "web",
};

const DEFAULT_DATA_SCOPE_MODE = DATA_SCOPE_MODES.WORK;

// V1.1-PHASE1: grammar-informed classification helpers
const {
  tokenize,
  parseTokens,
  semanticRoles,
} = require("./grammar");
// V1.1-PHASE2: rule normalizer imports
const {
  normalizeRules,
  deriveConstraints,
  mergeConstraints,
  evaluateConstraintAlgebra,
} = require("./ruleNormalizer");

// V1-PHASE1A: parser scaffold
function parseUserInput(raw) {
  return {
    normalized: raw?.trim() ?? "",
    detectedCommands: [],
    flags: [],
    entities: [],
    errors: [],
  };
}

// V1-PHASE1A: envelope scaffold
// V1-PHASE2: envelope population
function buildEnvelope(request, context = {}) {
  const normalized = typeof request === "string" ? request : request?.normalized || "";
  const hasVerb = /\b(create|draft|analyze|summarize|write|generate|plan|build|design)\b/i.test(normalized);
  const detectIntent = (parsedInput = "") => {
    if (hasVerb) return "action";
    if ((parsedInput || "").includes("?")) return "inquiry";
    return "unknown";
  };
  const userIntent = detectIntent(normalized);
  const requestType = context.requestType || REQUEST_TYPES.UNGOVERNED;
  const timestamp = new Date().toISOString();
  // V1-PHASE4: action category on envelope
  const detectActionCategory = (parsedInput = "") => {
    const txt = (parsedInput || "").toLowerCase();
    if (/\b(write|draft|generate)\b/.test(txt)) return "drafting";
    if (/\b(analyze|compare|evaluate)\b/.test(txt)) return "analysis";
    if (/\b(approve|sign|finalize|decide)\b/.test(txt)) return "decision";
    if (/\b(execute|run|trigger|deploy)\b/.test(txt)) return "execution";
    if (/\b(fetch|retrieve|pull data|query)\b/.test(txt)) return "data_access";
    return "other";
  };
  const actionCategory = detectActionCategory(normalized);
  return {
    userIntent,
    safetyBands: { level: "low" },
    constraints: [],
    actionCategory,
    metadata: {
      timestamp,
      requestType,
      languageModel: "gpt-5.1",
    },
  };
}

// V1-PHASE4: strengthened strictness logic
function computeStrictness(_request, rules = [], envelope = {}) {
  const requestType = envelope.requestType || REQUEST_TYPES.UNGOVERNED;
  const actionCategory = envelope.actionCategory || "other";
  const constraints = envelope.constraints || [];
  if (requestType === REQUEST_TYPES.CONVERSATIONAL) {
    return { level: 0, rationale: "non-governed text" };
  }
  if (requestType === REQUEST_TYPES.CLARIFICATION_RESPONSE) {
    return { level: 0, rationale: "clarification flow" };
  }
  if (!rules || rules.length === 0) {
    return { level: 0, rationale: "no rules configured" };
  }
  const highRiskCategory = actionCategory === "decision" || actionCategory === "execution";
  const hasHardBlockConstraint = constraints.some((c) => c.type === "hard_block");
  if (hasHardBlockConstraint || highRiskCategory) {
    return {
      level: 2,
      rationale: hasHardBlockConstraint
        ? "hard block constraint present"
        : "decision/execution category under governance",
    };
  }
  return {
    level: 1,
    rationale: "governed with active rules",
  };
}

// V1-PHASE2: functional request classifier
function classifyRequest(rawInput) {
  const text = (rawInput || "").trim().toLowerCase();
  const tokens = tokenize(text);
  const parsed = parseTokens(tokens);
  const semantics = semanticRoles(parsed);
  const casualMarkers = ["thanks", "thank you", "lol", "okay", "ok", "sounds good", "yeah", "great", "cool"];
  const hasRiskMarkers = (semantics.riskMarkers || []).length > 0; // TEST-A-FIX

  // V1.1-PHASE1: grammar-informed classification
  const noVerbs = parsed.verbs.length === 0;
  const beVerbsOnly = parsed.verbs.every((v) => ["be", "is", "are", "was", "were"].includes(v));

  // Clarification patterns (check before conversational catch-all) // TEST-A-FIX
  const shortReplies = ["yes", "no", "that works", "go ahead", "sure", "okay", "ok"];
  if (
    shortReplies.includes(text) ||
    text.startsWith("clarification") ||
    /use the/.test(text) ||
    /make it more/.test(text) ||
    /second version/.test(text) ||
    /that's fine/.test(text)
  ) {
    return REQUEST_TYPES.CLARIFICATION_RESPONSE;
  }

  // Governed patterns
  const actionVerbs = ["draft", "analyze", "evaluate", "compare", "summarize", "design", "create", "write", "generate", "execute", "deploy", "approve", "send", "finalize"];
  const isActionVerb = semantics.primaryVerb && actionVerbs.includes(semantics.primaryVerb);
  const hasObject = !!semantics.primaryObject;
  const isHypothetical = semantics.qualifiers.some((q) => ["hypothetical", "simulate", "simulation", "example", "sample"].includes(q));
  if (hasRiskMarkers) {
    return REQUEST_TYPES.GOVERNED;
  }
  if ((isActionVerb || hasRiskMarkers) && !isHypothetical) {
    return REQUEST_TYPES.GOVERNED;
  }
  if (hasObject && !isHypothetical && parsed.verbs.some((v) => actionVerbs.includes(v))) {
    return REQUEST_TYPES.GOVERNED;
  }

  // Ungoverned patterns (informational/Q&A)
  const qnaMarkers = ["what", "who", "when", "where", "why", "how", "should", "could"];
  const isQna = qnaMarkers.some((q) => text.startsWith(q)) || text.endsWith("?");
  if (isQna && !(isActionVerb || hasRiskMarkers)) {
    return REQUEST_TYPES.UNGOVERNED;
  }

  // Conversational patterns (fallback) // TEST-A-FIX
  if (noVerbs || beVerbsOnly || casualMarkers.some((c) => text.includes(c))) {
    return REQUEST_TYPES.CONVERSATIONAL;
  }

  return REQUEST_TYPES.UNGOVERNED;
}

// V1-PHASE2: minimal governance gate
function shouldGovern(requestType, rules = [], strictness = { level: 0 }) {
  if (requestType === REQUEST_TYPES.CONVERSATIONAL) return false;
  if (requestType === REQUEST_TYPES.CLARIFICATION_RESPONSE) return false;
  if (requestType === REQUEST_TYPES.GOVERNED) return true;
  if (strictness?.level > 0) return true;
  if (rules && rules.length > 0) return true;
  return false;
}

// V1-PHASE4: normalize constraints from parsed rules
function extractConstraintsFromRules(parsedRules = []) {
  const constraints = [];
  (parsedRules || []).forEach((rule) => {
    const text = (rule?.description || rule?.text || "").toLowerCase();
    const effect = (rule?.effect || rule?.action || "").toLowerCase();
    const id = rule?.id || rule?.ruleId;
    if (/block|deny|prohibit|forbid/.test(effect) || /do not proceed|never perform/.test(text)) {
      constraints.push({ type: "hard_block", sourceRuleId: id });
    }
    if (/approval|human review|requires approval/.test(text)) {
      constraints.push({ type: "requires_human_review", sourceRuleId: id });
    }
    if (/external\s+sharing|share externally/.test(text)) {
      constraints.push({ type: "no_external_sharing", sourceRuleId: id });
    }
    if (/production|prod/.test(text) && /execute|deploy|run/.test(text)) {
      constraints.push({ type: "no_production_execution", sourceRuleId: id });
    }
  });
  return constraints;
}

const hasHardBlockConstraintOrDenyRule = (rules = [], constraints = []) => {
  const hardConstraint = (constraints || []).some((c) => c.type === "hard_block");
  const denyRule = (rules || []).some((r) => /block|deny|prohibit|forbid/i.test(r?.effect || r?.action || r?.description || r?.text || ""));
  return hardConstraint || denyRule;
};

// V1.1-PHASE3: governance matrix wrapper
const { evaluateGovernanceMatrix } = require("./decisionMatrix");
function evaluateGovernance(requestType, rules = [], strictness = {}, envelope = {}, ctx = {}) {
  return evaluateGovernanceMatrix({
    requestType,
    strictness,
    actionCategory: envelope?.actionCategory,
    constraints: ctx.constraints || envelope?.constraints || [],
    constraintSummary: ctx.constraintSummary || { hardBlock: false },
    grammar: ctx.grammar || {},
    dataScopeMode: ctx.dataScopeMode,
    requestId: ctx.requestId,
    telemetry: ctx.telemetry,
  });
}

// V1-PHASE1A: cycle state shape
/**
 * CycleState {
 *   requestId: string
 *   requestType: REQUEST_TYPES
 *   strictness: object
 *   envelope: object
 *   parsedRules: any[]
 *   cycleStep: "A" | "M1" | "C" | "M2" | "V"
 * }
 */

// V1-PHASE1A: checkpoint scaffolds
function checkpointCycleState(state) {
  return { ...state };
}

function restoreCycleState(checkpoint) {
  return { ...checkpoint };
}

module.exports = {
  MCP_EVENTS,
  REQUEST_TYPES,
  GOVERNANCE_DECISIONS,
  DATA_SCOPE_MODES,
  DEFAULT_DATA_SCOPE_MODE,
  parseUserInput,
  buildEnvelope,
  computeStrictness,
  checkpointCycleState,
  restoreCycleState,
  classifyRequest,
  shouldGovern,
  evaluateGovernance,
  extractConstraintsFromRules,
  GOVERNANCE_DECISIONS,
  REQUEST_TYPES,
  tokenize,
  parseTokens,
  semanticRoles,
  normalizeRules,
  deriveConstraints,
  mergeConstraints,
  evaluateConstraintAlgebra,
};
