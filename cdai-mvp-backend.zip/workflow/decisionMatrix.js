// V1.1-PHASE3: deterministic governance decision matrix
// TEST-B-FIX: avoid circular dep destructuring by using safe fallbacks
let REQUEST_TYPES = {
  CONVERSATIONAL: "conversational",
  GOVERNED: "governed_request",
  UNGOVERNED: "ungoverned_request",
  CLARIFICATION_RESPONSE: "clarification_response",
};
let GOVERNANCE_DECISIONS = {
  ALLOW: "allow",
  REQUIRE_RULES: "require_rules",
  BLOCK: "block",
  ASK_CLARIFICATION: "ask_clarification",
};
let DATA_SCOPE_MODES = {
  WORK: "work",
  WEB: "web",
};
let DEFAULT_DATA_SCOPE_MODE = DATA_SCOPE_MODES.WORK;
try {
  const mod = require("./mcpPhase1A");
  REQUEST_TYPES = mod.REQUEST_TYPES || REQUEST_TYPES;
  GOVERNANCE_DECISIONS = mod.GOVERNANCE_DECISIONS || GOVERNANCE_DECISIONS;
  if (mod.DATA_SCOPE_MODES) {
    DATA_SCOPE_MODES = mod.DATA_SCOPE_MODES;
  }
  if (mod.DEFAULT_DATA_SCOPE_MODE) {
    DEFAULT_DATA_SCOPE_MODE = mod.DEFAULT_DATA_SCOPE_MODE;
  } else if (DATA_SCOPE_MODES?.WORK) {
    DEFAULT_DATA_SCOPE_MODE = DATA_SCOPE_MODES.WORK;
  }
} catch (e) {
  // best-effort fallback for early load during tests
}

// V1.2-PHASE2: detect when grammar implies a web/public action
function requestAppearsToRequireWebAccess(grammar = {}) {
  const w = grammar?.semantics?.primaryVerb || "";
  const obj = grammar?.semantics?.primaryObject || "";
  const qualifiers = grammar?.semantics?.qualifiers || [];
  const tokens = Array.isArray(grammar?.tokens) ? grammar.tokens.join(" ") : "";
  const rawText = grammar?.rawText || "";
  const text = `${w} ${obj} ${qualifiers.join(" ")} ${tokens} ${rawText}`.toLowerCase();
  return /search|lookup|find|web|online|external|public/.test(text); // V1.2-PHASE5-FIX: inspect qualifiers + tokens for web intent
}

function evaluateGovernanceMatrix({
  requestType,
  strictness = { level: 0 },
  actionCategory = "other",
  constraints = [],
  constraintSummary = { hardBlock: false },
  grammar = { semantics: { riskMarkers: [] } },
  dataScopeMode = DEFAULT_DATA_SCOPE_MODE,
  requestId = null,
  telemetry = null,
} = {}) {
  const summaryFlags = {
    webAccessForbidden: !!constraintSummary?.webAccessForbidden,
    citationRequired: !!constraintSummary?.citationRequired,
    provenanceRequired: !!constraintSummary?.provenanceRequired,
  };
  const requiresWeb = requestAppearsToRequireWebAccess(grammar);
  telemetry?.emit?.({
    event: "v1.2-matrix-eval",
    requestId,
    dataScopeMode,
    requiresWeb,
    summary: summaryFlags,
  });

  // CASE A — Conversational or Clarification
  if (
    requestType === REQUEST_TYPES.CONVERSATIONAL ||
    requestType === REQUEST_TYPES.CLARIFICATION_RESPONSE
  ) {
    return { outcome: GOVERNANCE_DECISIONS.ALLOW, rationale: "non-governed text" };
  }

  // CASE B — No Rules Present
  // TEST-C-FIX: only require_rules for low/medium drafting with no constraints; high-risk paths handled later
  if (
    requestType === REQUEST_TYPES.GOVERNED &&
    constraints.length === 0 &&
    (strictness?.level ?? 0) <= 1 &&
    (actionCategory === "drafting" || !actionCategory)
  ) {
    return { outcome: GOVERNANCE_DECISIONS.REQUIRE_RULES, rationale: "governed request with no active rules" };
  }

  // CASE C — Hard Block Constraint Exists
  if (constraintSummary?.hardBlock) {
    return { outcome: GOVERNANCE_DECISIONS.BLOCK, rationale: "hard-block constraint active" };
  }

  // V1.2-PHASE2: block external requests in work mode
  if (dataScopeMode === DATA_SCOPE_MODES.WORK && requiresWeb) {
    return {
      outcome: GOVERNANCE_DECISIONS.BLOCK,
      rationale: "external data forbidden in work mode",
    };
  }

  // V1.2-PHASE2: explicit constraint override
  if (summaryFlags.webAccessForbidden && requiresWeb) {
    return {
      outcome: GOVERNANCE_DECISIONS.BLOCK,
      rationale: "explicit rule forbids web access",
    };
  }

  // V1.2-PHASE2: web mode requires provenance context
  if (
    dataScopeMode === DATA_SCOPE_MODES.WEB &&
    !summaryFlags.provenanceRequired &&
    !summaryFlags.citationRequired
  ) {
    return {
      outcome: GOVERNANCE_DECISIONS.REQUIRE_RULES,
      rationale: "web mode requires provenance/citation rules to be active",
    };
  }

  // V1.2-PHASE2: strictness elevation when using external data
  if (dataScopeMode === DATA_SCOPE_MODES.WEB && requiresWeb) {
    if (!strictness || typeof strictness !== "object") {
      strictness = { level: 1 };
    } else {
      strictness.level = Math.max(strictness.level ?? 0, 1);
    }
  }

  // CASE D — Strictness 2 (High Risk)
  if (strictness?.level === 2) {
    if (actionCategory === "decision" || actionCategory === "execution") {
      return {
        outcome: GOVERNANCE_DECISIONS.ASK_CLARIFICATION,
        rationale: "high-risk action requires clarification",
      };
    }
    const riskMarkers = grammar?.semantics?.riskMarkers || [];
    if (
      riskMarkers.some((m) =>
        ["execute", "deploy", "send", "approve", "finalize", "external"].includes(m)
      )
    ) {
      return {
        outcome: GOVERNANCE_DECISIONS.ASK_CLARIFICATION,
        rationale: "risk markers detected under high strictness",
      };
    }
    return { outcome: GOVERNANCE_DECISIONS.ALLOW, rationale: "high strictness allowed" };
  }

  // CASE E — Strictness 1 (Medium Risk)
  if (strictness?.level === 1) {
    return { outcome: GOVERNANCE_DECISIONS.ALLOW, rationale: "medium strictness; no hard risk factors" };
  }

  // CASE F — Strictness 0 (Low Risk)
  return { outcome: GOVERNANCE_DECISIONS.ALLOW, rationale: "low strictness" };
}

module.exports = { evaluateGovernanceMatrix };
