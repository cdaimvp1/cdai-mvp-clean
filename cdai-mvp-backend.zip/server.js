require("dotenv").config();

const path = require("path");
const http = require("http");
const express = require("express");
const { Server } = require("socket.io");

const {
  runGovernedWorkflow,
  parseGovernanceEnvelope,
  resumeFromClarification,
} = require("./workflow/runGovernedWorkflow");
// V1-PHASE1C: checkpoint restore import
const { restoreCycleState } = require("./workflow/mcpPhase1A");
// V1-PHASE2: governance scaffolding imports
const {
  classifyRequest,
  computeStrictness,
  shouldGovern,
  REQUEST_TYPES,
  DATA_SCOPE_MODES,
  DEFAULT_DATA_SCOPE_MODE,
} = require("./workflow/mcpPhase1A");
const { VOLUME_1_STATUS } = require("./workflow/v1Status");
const { VOLUME_1_1_STATUS } = require("./workflow/v1_1Status");
const { classifyGovernanceIntent } = require("./workflow/openaiClient");
const { attachHarness, debugRoute } = require("./debug/eventHarness");
const { handleDataScopeModeChange } = require("./workflow/dataScopeModeHandler"); // V1.2-PHASE5-FIX

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
  },
});

const socketStates = new Map();
const pendingClarifications = new Map(); // HITL LOOP FIX

function normalizeRulesPayload(rawRules = []) {
  return (rawRules || []).map((r, idx) => {
    const text = typeof r === "string" ? r : r.text || r.description || "";
    const condition = typeof r === "string" ? r : r.condition || text || "";
    return {
      id: r.id || r.ruleId || `rule-${idx + 1}`,
      description: r.description || text,
      condition,
      severity:
        typeof r.severity === "number"
          ? r.severity
          : typeof r.severity === "string"
          ? r.severity
          : 1,
    };
  });
}

function emitParsedRules(ioInstance, rules = [], roomId = null) {
  if (!ioInstance) return;
  const payload = { rules: normalizeRulesPayload(rules), sessionId: roomId || undefined }; // EVENT MODEL FIX
  if (roomId && ioInstance.to) {
    ioInstance.to(roomId).emit("parsed-rules", payload);
    ioInstance.to(roomId).emit("governance-rules", payload);
  } else {
    ioInstance.emit("parsed-rules", payload);
    ioInstance.emit("governance-rules", payload);
  }
}

function shouldRunGovernance(message) {
  if (!message || typeof message !== "string") return false;

  const trimmed = message.trim().toLowerCase();

  const conversationalPatterns = [
    "lol",
    "okay",
    "thanks",
    "how are you",
    "what do you think",
    "i'm talking about",
    "tell me about",
    "i was thinking",
    "let's discuss",
  ];

  if (conversationalPatterns.some((p) => trimmed.startsWith(p))) return false;
  if (trimmed.length < 15) return false;

  const governedPatterns = [
    "generate",
    "create",
    "draft",
    "produce",
    "run",
    "analyze",
    "execute",
    "perform",
    "build",
    "compute",
    "summarize",
  ];

  if (governedPatterns.some((p) => trimmed.includes(p))) return true;

  return false;
}

async function runUngovernedResponse(socket, message) {
  const response =
    (message && message.trim()) ||
    "No governed action detected; ungoverned path taken.";
  socket.emit("ungoverned-output", { text: response });
  socket.emit("workflow-output", { text: response });
  socket.emit("workflow-finished", {});
}

app.post("/clear-rules", (_req, res) => {
  socketStates.forEach((state) => {
    if (state && Array.isArray(state.governanceRules)) {
      state.governanceRules = [];
    }
  });
  emitParsedRules(io, [], null);
  res.status(200).json({ ok: true });
});

app.post("/auth/logout", (_req, res) => {
  res.status(200).json({ ok: true });
});

if (process.env.DEBUG_EVENTS === "true") {
  debugRoute(app);
}

io.on("connection", (socket) => {
  const state = {
    id: socket.id,
    governanceRules: [],
    _driftState: null,
    _taskHistory: [],
    dataScopeMode: DEFAULT_DATA_SCOPE_MODE,
    pendingClarification: false,
  };

  socketStates.set(socket.id, state);
  emitParsedRules(io, state.governanceRules, socket.id);
  socket.emit("data-scope-mode-initial", { mode: state.dataScopeMode }); // V1.2-PHASE4

  // EVENT MODEL FIX: allow frontend to join session room explicitly
  socket.on("join-session", ({ sessionId }) => {
    if (sessionId) {
      socket.join(sessionId);
    }
  });

  socket.on("disconnect", () => {
    socketStates.delete(socket.id);
  });

  socket.on("clear-rules", () => {
    state.governanceRules = [];
    emitParsedRules(io, [], socket.id);
  });

  socket.on("reset-conversation", () => {
    state._driftState = null;
    state._taskHistory = [];
    io.to(socket.id).emit("telemetry", { type: "telemetry", subtype: "reset", sessionId: socket.id, data: {} }); // EVENT MODEL FIX
  });

  socket.on("set-data-scope-mode", (mode) => {
    handleDataScopeModeChange(state, socket, mode); // V1.2-PHASE5-FIX: shared handler ensures consistent behavior + testability
  });
  socket.on("panel-invocation-request", (payload = {}) => {
    const requestId = payload?.requestId || `panel-${Date.now()}`;
    const response = {
      allowed: true,
      panelKey: payload?.panelKey || null,
      context: payload?.context || null,
      timestamp: Date.now(),
      message: "Panel invocation acknowledged (placeholder).",
      requestId,
    };
    socket.emit("panel-invocation-response", response);
  });

  socket.on("run-workflow", async (payload = {}) => {
    if (!state.dataScopeMode) {
      state.dataScopeMode = DEFAULT_DATA_SCOPE_MODE; // V1.2-PHASE4: ensure mode persists
    }
    const {
      input = "",
      goal = "",
      maxCycles = null,
      governanceStrictness = 0.85,
      perfMode = "real",
      rules = undefined,
      requiresGovernedOutput = false,
      sessionId = null,
      runId = null,
    } = payload;

    if (sessionId) {
      socket.join(sessionId);
    }

    const roomTarget = sessionId || socket.id;

    const inboundRules =
      rules === undefined
        ? state.governanceRules
        : Array.isArray(rules) && rules.length > 0
        ? rules
        : state.governanceRules;

    if (Array.isArray(rules) && rules.length > 0) {
      state.governanceRules = rules;
    }

    try {
      const envelope = parseGovernanceEnvelope(input || "");
      const intent = await classifyGovernanceIntent(input || "");
      const requestType = classifyRequest(input || "");
      const strictnessMeta = computeStrictness(input || "", inboundRules, { requestType });

      if (intent && intent.label === "rule_addition") {
        const ruleText =
          (intent.ruleCandidates && intent.ruleCandidates[0]) ||
          input.replace(/add rule:?/i, "").trim();
        if (ruleText) {
          state.governanceRules.push({
            text: ruleText,
            origin: "user",
            status: "pending",
          });
          emitParsedRules(io, state.governanceRules, roomTarget);
        }
        return;
      }

      const parsedPayload = { rules: normalizeRulesPayload(inboundRules), sessionId: roomTarget };
      io.to(roomTarget).emit("parsed-rules", parsedPayload);
      io.to(roomTarget).emit("governance-rules", parsedPayload);

      // V1-PHASE2: requestType-aware ungoverned gating
      const shouldGovernResult = shouldGovern(requestType, inboundRules, strictnessMeta);
      const allowGovernance = shouldGovernResult && shouldRunGovernance(input || "");
      if (!allowGovernance) {
        if (requestType === REQUEST_TYPES.GOVERNED && shouldGovernResult) {
          console.warn("[MCP][Invariant] Governed request attempted to use ungoverned shortcut; forcing governed path.", {
            requestId: runId || roomTarget,
          });
        } else {
          await runUngovernedResponse(socket, input || "");
          return;
        }
      }

      runGovernedWorkflow._inFlight = false;
      const result = await runGovernedWorkflow(socket, {
        input,
        goal,
        maxCycles,
        governanceStrictness,
        perfMode,
        rules: inboundRules,
        governanceEnvelope: envelope,
        requiresGovernedOutput,
        sessionId: roomTarget,
        runId: runId || roomTarget,
        dataScopeMode: state.dataScopeMode || DEFAULT_DATA_SCOPE_MODE,
      });

      if (result?.paused && result.context) {
        pendingClarifications.set(roomTarget, result.context);
        state.pendingClarification = true;
      }
    } catch (err) {
      console.error("Workflow error:", err);
      io.to(roomTarget).emit("governance-errors", { error: String(err?.message || err) });
      // EVENT MODEL FIX: emit telemetry in standard shape and scoped to session
      io.to(roomTarget).emit("telemetry", {
        type: "telemetry",
        subtype: "error",
        sessionId: roomTarget,
        data: { message: String(err && err.message ? err.message : err) },
      });
    }
  });

  socket.on("clarification-response", async (payload = {}) => {
    const { sessionId = null, runId = null, clarificationAnswer = "" } = payload;
    const roomTarget = sessionId || socket.id;
    const checkpoint = pendingClarifications.get(roomTarget);
    if (!checkpoint) return;
    // V1-PHASE1C: restore MCP checkpoint
    const restoredState = restoreCycleState(checkpoint);
    pendingClarifications.delete(roomTarget);
    state.pendingClarification = false;
    io.to(roomTarget).emit("clarification-accepted", { sessionId: roomTarget, runId: runId || roomTarget });
    await resumeFromClarification(socket, restoredState, clarificationAnswer);
  });
});

if (process.env.DEBUG_EVENTS === "true") {
  attachHarness(io);
}

console.log("[cd/ai] Volume 1 governance status:", VOLUME_1_STATUS);
console.log("[cd/ai] Volume 1.1 status:", VOLUME_1_1_STATUS);

function getSessionMode(sessionId) {
  const session = socketStates.get(sessionId);
  if (!session) return DEFAULT_DATA_SCOPE_MODE;
  if (!session.dataScopeMode) {
    session.dataScopeMode = DEFAULT_DATA_SCOPE_MODE;
  }
  return session.dataScopeMode;
}

const PORT = process.env.PORT || 5006;
server.listen(PORT, () => {
  console.log(`[cd/ai] Server running on port ${PORT}`);
});

module.exports = server;
module.exports.getSessionMode = getSessionMode;
